
df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

attach(df)

model = lm(prop ~ fw + de + du, data = df)

summary(model)






