# This is to preprocess the Free Will Inventory (FWI)

library(tidyverse)
library(psych)

# Read the questionnaire

df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# Rename the column

df = subset(df, select = c(1, 6:26))

names(df)[1] = 'response_id'
names(df)[2] = 'ip'
names(df)[3] = 'prolific_id'
names(df)[4] = 'education'
names(df)[5] = 'gender'
names(df)[6] = 'age'
names(df)[7] = 'country'
names(df)[8] = 'f01'
names(df)[9] = 'f02'
names(df)[10] = 'f03'
names(df)[11] = 'f04'
names(df)[12] = 'f05'
names(df)[13] = 'f06'
names(df)[14] = 'f07'
names(df)[15] = 'f08'
names(df)[16] = 'f09'
names(df)[17] = 'f10'
names(df)[18] = 'f11'
names(df)[19] = 'f12'
names(df)[20] = 'f13'
names(df)[21] = 'f14'
names(df)[22] = 'f15'


# Calculating the Free Will Inventory 

for (i in 1:dim(df)[1]) {
  for (j in 1:dim(df)[2]) {
    if (df[i, j] == 'Strongly disagree') {
      df[i, j][df[i, j] == 'Strongly disagree'] = 1
    } else if (df[i, j] == 'Disagree') {
      df[i, j][df[i, j] == 'Disagree'] = 2
    } else if (df[i, j] == 'Somewhat disagree') {
      df[i, j][df[i, j] == 'Somewhat disagree'] = 3
    } else if (df[i, j] == 'Neither agree nor disagree') {
      df[i, j][df[i, j] == 'Neither agree nor disagree'] = 4
    } else if (df[i, j] == 'Somewhat agree') {
      df[i, j][df[i, j] == 'Somewhat agree'] = 5
    } else if (df[i, j] == 'Agree') {
      df[i, j][df[i, j] == 'Agree'] = 6
    } else if (df[i, j] == 'Strongly agree') {
      df[i, j][df[i, j] == 'Strongly agree'] = 7
    }
  }
}

freewill = c(8, 11, 14, 17, 20)
determinism = c(9, 12, 15, 18, 21)
dualism = c(10, 13, 16, 19, 22)

df$fw = rowSums(sapply(df[, freewill], as.numeric))

df$de = rowSums(sapply(df[, determinism], as.numeric))

df$du = rowSums(sapply(df[, dualism], as.numeric))

# Write into .csv file

write.table(df, file = paste0('survey', '.csv'), sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")

