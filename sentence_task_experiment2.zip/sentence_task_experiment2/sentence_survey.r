# To merge the data in sentence task with the data in survey

library(tidyverse)

# Read the sentence results

df_sentence = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# Read the Free Will Inventory

df_survey = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# Start to match the two datasets by prolific id

df_survey$prolific_id[duplicated(df_survey$prolific_id)]
df_sentence$prolific_id[duplicated(df_sentence$prolific_id)]


df_sentence = subset(df_sentence, df_sentence$prolific_id %in% df_survey$prolific_id)


for (i in 1:dim(df_survey)[1]) {
  for (j in 1:dim(df_sentence)[1]) {
    if (df_survey[i, 3] == df_sentence[j, 1]) {
      df_survey[i, 26] = df_sentence[j, 2]
      df_survey[i, 27] = df_sentence[j, 3]
      df_survey[i, 28] = df_sentence[j, 4]
      df_survey[i, 29] = df_sentence[j, 5]
      df_survey[i, 30] = df_sentence[j, 6]
      df_survey[i, 31] = df_sentence[j, 7]
      df_survey[i, 32] = df_sentence[j, 8]
      
    }
  }
}

# Renaming the column

names(df_survey)[26] = 'ip'
names(df_survey)[27] = 'null_total'
names(df_survey)[28] = 'null_ambiguous'
names(df_survey)[29] = 'acc_acc'
names(df_survey)[30] = 'acc_int'
names(df_survey)[31] = 'accuracy'
names(df_survey)[32] = 'prop'

# resorting the response id by ascending order

df_survey = df_survey[order(df_survey$response_id), ]

df_survey = na.omit(df_survey)

write.table(df_survey, file = paste0('sentence_survey', '.csv'), sep = ',', col.names = TRUE,
            row.names = FALSE, qmethod = 'double')

