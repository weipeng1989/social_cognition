# This script is to detect the participants who didn't respond on more than 20% of the total trials. # nolint

library(tidyverse)

# Batch reading the file

filenames = list.files(path = getwd(), pattern = 'SentenceTask_+.*csv')

# Creating prolific id

prolific_id = substr(filenames, 14, 37)

integration = data.frame(prolific_id = character(), ip = character(), null_total = double(), null_ambiguous = double(), 
                         acc_acc = double(), acc_int = double(), accuracy = double(),
                       prop = double(), stringsAsFactors = FALSE)[1:length(prolific_id), ]

# Counting the number for total null response, null response in ambiguous sentences and accuracy

for (i in 1:length(prolific_id)) {
  
  df = read.csv(paste0('SentenceTask_', prolific_id[i], '.csv'),
                     header = TRUE, sep = ',', stringsAsFactors = FALSE)
  null_total = 0
  for (j in 1:dim(df)[1]) {
    if (df[j, 3] == 'null') {
      null_total = null_total + 1
    }
  }
  
  null_ambiguous = 0
  for (j in 1:dim(df)[1]) {
    if ((df[j, 3] == 'null' && df[j, 4] == 'prototypically_accidental') 
        | df[j, 3] == 'null' && df[j, 4] == 'neutral/prototypically_intentional') {
      null_ambiguous = null_ambiguous + 1
    }
  }
  
  # selection of 'unambiguously_accidental'
  df_acc = df[df$type == 'unambiguously_accidental', ]
  # selection of 'unambiguously_intentional'
  df_int = df[df$type == 'unambiguously_intentional', ]
  length(which(df_acc$resp_label == 'acc'))
  length(which(df_int$resp_label == 'int'))
  
  # selection of test sentences
  df_test = df[df$type == 'prototypically_accidental'
                    | df$type == 'neutral/prototypically_intentional', ]
  df_test$resp_label[df_test$resp_label == 'acc'] = 0
  df_test$resp_label[df_test$resp_label == 'int'] = 1
  
  integration[i, 1] = prolific_id[i]
  integration[i, 2] = df[1, 9]
  integration[i, 3] = null_total
  integration[i, 4] = null_ambiguous
  integration[i, 5] = length(which(df_acc$resp_label == 'acc'))
  integration[i, 6] = length(which(df_int$resp_label == 'int'))
  integration[i, 7] = (length(which(df_acc$resp_label == 'acc')) + 
                         length(which(df_int$resp_label == 'int'))) / 20
  integration[i, 8] = length(which(df_test$resp_label == 1)) / dim(df_test)[1]
  
}

write.table(integration, file = paste0('sentence_summary', '.csv'), sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")


