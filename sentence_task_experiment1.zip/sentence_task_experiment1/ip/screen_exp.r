# To screen the qualified participants we need. Based on two criteria: 
# reading-time > 45000ms, and got the correct answer in the final question.


# this is to add ip and combine all the files into one

# Put all the file into the current directory

library(tidyverse)

# batch reading the data

filenames = list.files(path = getwd(), pattern = 'Manipulation_ExpGrp_+.*csv')

# creating prolific id

prolific_id = substr(filenames, 21, 44)

# batch add missing ip

for (i in 1:length(prolific_id)) {
  df = read.csv(paste0('Manipulation_ExpGrp_', prolific_id[i], '.csv'), 
                header = TRUE, sep = ',', stringsAsFactors = FALSE)
  if (ncol(df) < 10) {
    df = add_column(df, ip = 'no_ip', .before = 'prolific')
    write.table(df,
                file = paste0('Manipulation_ExpGrp_', prolific_id[i],'.csv'), 
                sep = ',', col.names = TRUE,
                row.names = FALSE, qmethod = 'double')
  }
}

# define empty data frame
df_manipulation = data.frame(view_history = character(), rt = double(), trial_type = character(),
                             trial_index = double(), time_elapsed = double(), 
                             internal_node_id = character(), ip = character(),
                             prolific = character(), write = character(), summary = character(),
                             stringsAsFactors = FALSE)
# combine rows 
for (i in 1:length(prolific_id)) {
  df = read.csv(paste0('Manipulation_ExpGrp_', prolific_id[i], '.csv'), 
                header = TRUE, sep = ',', stringsAsFactors = FALSE)
  df_manipulation[i, ] = df[1, 1:10]
}

# write into tables

write.table(df_manipulation,
            file = paste0('manipulation_combined_ExpGrp','.csv'), 
            sep = ',', col.names = TRUE,
            row.names = FALSE, qmethod = 'double')

##################################################################################
# start to do the survey and manipulation


id = data.frame(response_id = double(),
                prolific_id = character(), ip = character(), 
                reading_time = double(), stringsAsFactors = FALSE)

df_survey = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

df_manipulation = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

df_survey = subset(df_survey, select = c(1, 8:29))

names(df_survey)[1] = 'response_id'
names(df_survey)[2] = 'ip'
names(df_survey)[3] = 'prolific_id'
names(df_survey)[4] = 'education'
names(df_survey)[5] = 'gender'
names(df_survey)[6] = 'age'
names(df_survey)[7] = 'country'
names(df_survey)[8] = 'f01'
names(df_survey)[9] = 'f02'
names(df_survey)[10] = 'f03'
names(df_survey)[11] = 'f04'
names(df_survey)[12] = 'f05'
names(df_survey)[13] = 'f06'
names(df_survey)[14] = 'f07'
names(df_survey)[15] = 'f08'
names(df_survey)[16] = 'f09'
names(df_survey)[17] = 'f10'
names(df_survey)[18] = 'f11'
names(df_survey)[19] = 'f12'
names(df_survey)[20] = 'f13'
names(df_survey)[21] = 'f14'
names(df_survey)[22] = 'f15'
names(df_survey)[23] = 'exp_q'

# now dealing with questions

exp_q = as.character(df_survey$exp_q)

for (j in 1:length(exp_q)) {
  exp_q[j] = ifelse(exp_q[j] == 'In the postscript, Francis Crick argues that free will is an illusion.', '100%', '0%')
}

df_survey$exp_q = exp_q

# calculate the free will beliefs (don't reverse the Determinism subscale)
# dimension of the dataframe

for (i in 1:dim(df_survey)[1]) {
  for (j in 1:dim(df_survey)[2]) {
    if (df_survey[i, j] == 'Strongly disagree') {
      df_survey[i, j][df_survey[i, j] == 'Strongly disagree'] = 1
    } else if (df_survey[i, j] == 'Disagree') {
      df_survey[i, j][df_survey[i, j] == 'Disagree'] = 2
    } else if (df_survey[i, j] == 'Somewhat disagree') {
      df_survey[i, j][df_survey[i, j] == 'Somewhat disagree'] = 3
    } else if (df_survey[i, j] == 'Neither agree nor disagree') {
      df_survey[i, j][df_survey[i, j] == 'Neither agree nor disagree'] = 4
    } else if (df_survey[i, j] == 'Somewhat agree') {
      df_survey[i, j][df_survey[i, j] == 'Somewhat agree'] = 5
    } else if (df_survey[i, j] == 'Agree') {
      df_survey[i, j][df_survey[i, j] == 'Agree'] = 6
    } else if (df_survey[i, j] == 'Strongly agree') {
      df_survey[i, j][df_survey[i, j] == 'Strongly agree'] = 7
    }
  }
}

freewill = c(8, 11, 14, 17, 20)
determinism = c(9, 12, 15, 18, 21)
dualism = c(10, 13, 16, 19, 22)


# calculating the free will beliefs

df_survey$fw = rowSums(sapply(df_survey[, freewill], as.numeric))

# calculating the Determinism

df_survey$de = rowSums(sapply(df_survey[, determinism], as.numeric))

# calculating the dualism subscale

df_survey$du = rowSums(sapply(df_survey[, dualism], as.numeric))

########################################################################################
# starting marching manipulation data with id by ip address, 
# first to sort manipulation data

# This function is designed to extract value from the string.

extract_value = function(s) {
  if (length(s) == 16) {
    reading_time = readr::parse_number(s[4]) + readr::parse_number(s[8]) + readr::parse_number(s[12]) 
    + readr::parse_number(s[16])
  } else if (length(s) == 12) {
    reading_time = readr::parse_number(s[4]) + readr::parse_number(s[8]) + readr::parse_number(s[12])
  } else if (length(s) == 8) {
    reading_time = readr::parse_number(s[4]) + readr::parse_number(s[8])
  } else {
    reading_time = readr::parse_number(s[4])
  }
  return(reading_time)
}

# Create data frame

time_stats= data.frame(prolific_id = character(), ip = double(), reading_time = double(), 
                       stringsAsFactors = FALSE)


# extract reading time
for (i in 1:length(df_manipulation$prolific)) {
  stringlist = as.character(df_manipulation$view_history[i])
  s = unlist(strsplit(stringlist, split = ',', fixed = TRUE))
  reading_time = extract_value(s)
  time_stats[i, 1] = paste0(df_manipulation$prolific[i])
  time_stats[i, 2] = df_manipulation[i, 7]
  time_stats[i, 3] = reading_time
}

# matching the survey data with manipulation data by prolific id

for (i in 1:dim(df_survey)[1]) {
  for (j in 1:dim(time_stats)[1]) {
    if (df_survey[i, 3] == time_stats[j, 1]) {
      id[i, 1] = df_survey[i, 1]
      id[i, 2] = df_survey[i, 3]
      id[i, 3] = df_survey[i, 2]
      id[i, 4] = time_stats[j, 3]
    }
  }
}

# add multiple column
id = cbind(id, df_survey[, 4:26])

# sorting the response_id by ascending order

id = id[order(id$response_id), ]

# remove NA (once I find a 'NA', delete the whole row)

id = id[complete.cases(id), ]

id = filter(id, id$reading_time >= 45000 & id$exp_q == '100%')

write.table(id, file = "id_exp.csv", sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")


