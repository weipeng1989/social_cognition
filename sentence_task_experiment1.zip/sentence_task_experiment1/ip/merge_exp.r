
# Firstly, please check the integrity of all the files

library(tidyverse)

# batch reading the data

filenames = list.files(path = getwd(), pattern = 'SentenceTask_ExpGrp_+.*csv')

# creating prolific id

prolific_id = substr(filenames, 21, 44)

integrity = data.frame(prolific_id = character(), nrow = double(), ncol = double(),
                       stringsAsFactors = FALSE)[1:length(prolific_id), ]


# batch calculate the number of rows for individual file

for (i in 1:length(prolific_id)) {
  df = read.csv(paste0('SentenceTask_ExpGrp_', prolific_id[i], '.csv'), 
                header = TRUE, sep = ',', stringsAsFactors = FALSE)
  integrity[i, 1] = prolific_id[i]
  integrity[i, 2] = nrow(df)
  integrity[i, 3] = ncol(df)
}

# batch add missing ip (no_ip)

for (i in 1:length(prolific_id)) {
  df = read.csv(paste0('SentenceTask_ExpGrp_', prolific_id[i], '.csv'), 
                header = TRUE, sep = ',', stringsAsFactors = FALSE)
  if (ncol(df) < 13) {
    df = add_column(df, ip = 'no_ip', .before = 'prolific')
    write.table(df,
                file = paste0('SentenceTask_ExpGrp_', prolific_id[i],'.csv'), 
                sep = ',', col.names = TRUE,
                row.names = FALSE, qmethod = 'double')
  }
}

###############################################################################

# Manipulation check

acc = data.frame(prolific_id = character(), acc_acc = double(), acc_int = double(), prop = double(),
                 stringsAsFactors = FALSE)

for (i in 1:length(prolific_id)) {
  df = read.csv(paste0('SentenceTask_ExpGrp_', prolific_id[i], '.csv'), 
                header = TRUE, sep = ',', stringsAsFactors = FALSE)
  
  # selection of 'unambiguously_accidental'
  df_acc = df[df$type == 'unambiguously_accidental', ]
  # selection of 'unambiguously_intentional'
  df_int = df[df$type == 'unambiguously_intentional', ]
  length(which(df_acc$resp_label == 'acc'))
  length(which(df_int$resp_label == 'int'))
  # selection of test sentences
  df_test = df[df$type == 'prototypically_accidental'
               | df$type == 'neutral/prototypically_intentional', ]
  df_test$resp_label[df_test$resp_label == 'acc'] = 0
  df_test$resp_label[df_test$resp_label == 'int'] = 1
  acc[i, 1] = prolific_id[i]
  acc[i, 2] = length(which(df_acc$resp_label == 'acc'))
  acc[i, 3] = length(which(df_int$resp_label == 'int'))
  acc[i, 4] = length(which(df_test$resp_label == 1)) / dim(df_test)[1]
  
}

# identify duplicate 

acc$prolific_id[duplicated(acc$prolific_id)]

write.table(acc,
            file = paste0('acc_exp', '.csv'), sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")

#####################################################################################

# Combine sentence data with survey data

# reading sorted id data

id = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

id$prolific_id[duplicated(id$prolific_id)]

attach(id)
attach(acc)

# Choose the valid prolific id
acc = subset(acc, acc$prolific_id %in% id$prolific_id)

# starting matching

for (i in 1:dim(id)[1]) {
  for (j in 1:dim(acc)[1]) {
    if (id[i, 2]== acc[j, 1]) {
      id[i, 28] = acc[j, 1]
      id[i, 29] = acc[j, 2]
      id[i, 30] = acc[j, 3]
      id[i, 31] = acc[j, 4]
    }
  }
}

# renaming the column

names(id)[28] = 'prolific_id_acc'
names(id)[29] = 'acc_acc'
names(id)[30] = 'acc_int'
names(id)[31] = 'prop'

# remove NA (once I find a 'NA', i will delete the whole row)

id = id[complete.cases(id), ]

# resorting the Response_id by ascending order

id = id[order(id$response_id), ]

write.table(id,
            file = paste0('id_exp_sentence', '.csv'), sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")




c(setdiff(acc$prolific_id, id$prolific_id), 
  setdiff(id$prolific_id, acc$prolific_id))