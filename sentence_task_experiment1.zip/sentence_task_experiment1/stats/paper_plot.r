
# This is to plot scatter figure
# V.V Peng

library(ggplot2)
library(gridExtra)
library(Hmisc)
library(grid)
library(lattice)
library(latticeExtra)

# read data
df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

attach(df)

# P1: free will

p1 = ggplot(df, aes(fw, prop)) + geom_point() + xlab("Belief in free will") + ylab("Intentionality bias") + 
    stat_smooth(method = lm, color = "black") + theme(axis.title.y = element_text(color = 'black', family = 'Arial',
                                  face = 'bold', size = 18, vjust = 0.5, angle = 90), 
                                  axis.title.x = element_text(color = 'black', family = 'Arial',
                                                              face = 'bold', size = 18, hjust = 0.5, angle = 0))

# p2: determinism

p2 = ggplot(df, aes(de, prop)) + geom_point() + xlab("Belief in determinism") + ylab("Intentionality bias") + 
  stat_smooth(method = lm, color = "black") + theme(axis.title.y = element_text(color = 'black', family = 'Arial',
                                                                                face = 'bold', size = 18, vjust = 0.5, angle = 90), 
                                                    axis.title.x = element_text(color = 'black', family = 'Arial',
                                                                                face = 'bold', size = 18, hjust = 0.5, angle = 0))

# p3: dualism

p3 = ggplot(df, aes(du, prop)) + geom_point() + xlab("Belief in dualism") + ylab("Intentionality bias") + 
  stat_smooth(method = lm, color = "black") + theme(axis.title.y = element_text(color = 'black', family = 'Arial',
                                                                                face = 'bold', size = 18, vjust = 0.5, angle = 90), 
                                                    axis.title.x = element_text(color = 'black', family = 'Arial',
                                                                                face = 'bold', size = 18, hjust = 0.5, angle = 0))

# dev.cur()
# dev.off()

pushViewport(viewport(layout = grid.layout(2, 2)))
print(p1, vp = viewport(layout.pos.row = 1, layout.pos.col = 1)) 
print(p2, vp = viewport(layout.pos.row = 1, layout.pos.col = 2))
print(p3, vp = viewport(layout.pos.row = 2, layout.pos.col = 1))

