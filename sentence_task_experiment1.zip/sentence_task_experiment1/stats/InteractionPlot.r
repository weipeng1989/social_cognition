# This is to plot interaction effect of the ANCOVA

library(interplot)

library(tidyverse)
library(ggplot2)
library(car)
library(lme4)
library(lmerTest)
library(afex)
library(ez) 
library(tidyverse)
library(lsmeans)
library(magrittr)
library(emmeans)
library(WRS2)
library(pastecs)
library(ggpubr)
library(rstatix)
library(reshape)
library(psych)
library(multcompView)
library(FSA)
library(phia)
library(cowplot)
library(jtools)
library(ggbeeswarm)

# loading the data

df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

attach(df)

interaction.plot(x.factor = df$du, 
                 trace.factor = df$group,
                 response = df$prop)


interaction.plot(x.factor = df$group, 
                 trace.factor = df$du,
                 response = df$prop)
