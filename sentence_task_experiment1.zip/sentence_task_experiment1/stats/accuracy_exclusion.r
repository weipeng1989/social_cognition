
# calculating the accuracy of control sentence

df = read.csv(file.choose(), header = T, sep = ",", stringsAsFactors = FALSE)

# calculating the accuracy now...

df$acc_control = (df$acc_acc + df$acc_int) / 20


write.table(df, file = paste0('id_exp_sentence_ipnoip_exclu', '.csv'), sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")
